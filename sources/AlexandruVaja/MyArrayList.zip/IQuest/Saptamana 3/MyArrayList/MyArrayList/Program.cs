﻿using System;


namespace MyArrayList
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            MyArrayList<string> array = new MyArrayList<string>();
            array.Add("mere");
            array.Add("pere");
            array.Add("mandarine");
            array.Add("ananas");
            array.Add("babane");
            array.Add("smochine");
            Console.WriteLine(array.Count());
            for (int i=0; i<array.Count(); i++)
                Console.WriteLine(array.GetItem(i));
            Console.WriteLine("");
            array.Remove("ananas");
            Console.WriteLine(array.Count());
            for (int i = 0; i < array.Count(); i++)
                Console.WriteLine(array.GetItem(i));
        }
    }
}
