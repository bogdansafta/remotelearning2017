﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace MyArrayList
{
    class MyArrayList<T>
    {
        object[] elementData;
        object[] INITIAL_DATA = { };
        int size = 0;
        public MyArrayList(int initialCapacity)
        {
            if (initialCapacity > 0)
            {
                this.elementData = new Object[initialCapacity];
            }
            else if (initialCapacity == 0)
            {
                this.elementData = INITIAL_DATA;
            }
            else Console.WriteLine("Dimensiune incorecta!");
        }

        public MyArrayList()
        {
            this.elementData = INITIAL_DATA;
        }


        public void Add(T newObject)
        {
            object[] copyData = elementData;
            ++size;
            elementData = new object[size];
            for (int i = 0; i < copyData.Length; i++)
                elementData[i] = copyData[i];
            elementData[size - 1] = newObject;
        }

        public void Remove(T element)
        {
            object[] copyData = new object[size - 1];
            Boolean ok = true;
            for (int i = 0; i < elementData.Length - 1; i++)
            {
                if (!elementData[i].Equals(element) && ok)
                {
                    copyData[i] = elementData[i];
                }
                else ok = false; 
                if (!ok)
                    copyData[i] = elementData[i + 1];
            }
            elementData = new object[copyData.Length];
            elementData = copyData;
            size--;
        }
        public int Count()
        {
            return this.size;
        }

        public object GetItem(int x)
        {
            return elementData[x];
        }

        public object LastElement()
        {
            return this.elementData[size - 1];
        }

        public object FirstElement()
        {
            return this.elementData[0];
        }
    }
}
