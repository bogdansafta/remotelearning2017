﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine
{
    class Product
    {
        private string typeProduct;
        private string nameProduct;
        private double priceProduct;
        private int quantityProduct;
        private int sizeProduct;
        
        public Product()
        {
            typeProduct = null;
            nameProduct = null;
            priceProduct = 0.0;
            quantityProduct = 0;
            sizeProduct = 0;
        }

        public Product(string newTypeProduct, string newNameProduct, double newPriceProduct, int newQuantityProduct, int newSizeProduct)
        {
            this.typeProduct = newTypeProduct;
            this.nameProduct = newNameProduct;
            this.priceProduct = newPriceProduct;
            this.quantityProduct = newQuantityProduct;
            this.sizeProduct = newSizeProduct;
        }

        public override String ToString()
        {
            return (GetType() + " " + GetName() + " " + GetQuantity());
        }
        public string GetType()
        {
            return typeProduct;
        }
        public void SetType(string value)
        {
            typeProduct = value;
        }
        public string GetName()
        {
            return nameProduct;
        }
        private void SetName(string value)
        {
            nameProduct = value;
        }
        public int GetQuantity()
        {
            return quantityProduct;
        }
        public void SetQuantity(int value)
        {
            quantityProduct = value;
        }
        private int GetSize()
        {
            return sizeProduct;
        }
        private void SetSize(int value)
        {
            sizeProduct = value;
        }
    }
}
