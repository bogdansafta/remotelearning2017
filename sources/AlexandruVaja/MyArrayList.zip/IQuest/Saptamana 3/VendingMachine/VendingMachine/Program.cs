﻿using System;

namespace VendingMachine
{
    class Program
    {
        static void Main(string[] args)
        {
            MyArrayList<Product> produs = new MyArrayList<Product>();
            produs.Add(new Product("Croco", "Mac", 6.7, 4, 1));
            





            /*produs.Add(1);
            produs.Add(2);
            produs.Add(3);
            produs.Add(4);
            produs.Add(5);
            produs.Add(6);
            for (int i = 0; i < produs.Count(); i++)
                Console.WriteLine(produs.GetItem(i));
            Console.WriteLine("");
            produs.Remove(2);
            for(int i=0;i<produs.Count();i++)
                Console.WriteLine(produs.GetItem(i));
            //Console.WriteLine(produs.LastElement());*/

        }
    }
}
