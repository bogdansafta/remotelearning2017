﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace VendingMachine
{
    class MyArrayList<T> 
    {
        object[] elementData;
        object[] INITIAL_DATA = { };
        int size = 0;
        public MyArrayList(int initialCapacity)
        {
            if (initialCapacity > 0)
            {
                this.elementData = new Object[initialCapacity];
            }
            else if (initialCapacity == 0)
            {
                this.elementData = INITIAL_DATA;
            }
            else Console.WriteLine("Dimensiune incorecta!");
        }

        public MyArrayList()
        {
            this.elementData = INITIAL_DATA;
        }

        public MyArrayList(T colectie)
        {
            Console.WriteLine("Urmeaza sa fie implementata!");
        }

        public void Add(T newObject)
        {
            object[] copyData = elementData;
            ++size;
            elementData = new object[size];
            for (int i = 0; i < copyData.Length; i++)
                elementData[i] = copyData[i];
            elementData[size - 1] = newObject;
        }

        public void Remove(T element)
        {
            object[] copyData = new object[size];
            Boolean ok = true;
            for (int i=0;i<elementData.Length;i++)
                if(!elementData[i].Equals(element) && ok)
                {
                    copyData.SetValue(elementData[i], i);
                    ok = false;
                } else copyData.SetValue(elementData[i - 1], i);
            elementData = copyData;
        }
        public int Count()
        {
            return this.size;
        }

        public object GetItem(int x)
        {
            return elementData[x];
        }
        
        public object LastElement()
        {
            return this.elementData[size - 1];
        }

        public object FirstElement()
        {
            return this.elementData[0];
        }
    }
}
