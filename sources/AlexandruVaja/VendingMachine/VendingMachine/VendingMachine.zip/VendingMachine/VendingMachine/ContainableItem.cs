﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine
{
    class ContainableItem : IEquatable<ContainableItem>
    {
        public Position position = new Position();
        public Product product = new Product();

        public bool Equals(ContainableItem other)
        {
            if (Equals(other.position)) //!Position.Equals(other.productPosition)
                return false;
            return true;
        }
    }
}
