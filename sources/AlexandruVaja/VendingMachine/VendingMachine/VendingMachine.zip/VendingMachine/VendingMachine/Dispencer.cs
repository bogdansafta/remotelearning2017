﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine
{
    class Dispencer
    {
        public ContainableItemCollection dispensedProduct = new ContainableItemCollection();

        public Product Dispense(Position id)
        {
            if (dispensedProduct == null)
                throw new System.Exception("Invalid id!");
            return dispensedProduct.GetByPosition(id) as Product;
        }
    }
}
