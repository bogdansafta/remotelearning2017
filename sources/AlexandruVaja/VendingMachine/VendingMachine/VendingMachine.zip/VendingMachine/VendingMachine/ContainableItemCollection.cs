﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace VendingMachine
{
    class ContainableItemCollection
    {
        ProductList<ContainableItem> productList = new ProductList<ContainableItem>();

        public void Add(ContainableItem newProduct)
        {
            productList.Add(newProduct);
        }

        public void Remove(ContainableItem product)
        {
            productList.Remove(product);
        }

        public int Count() => productList.Count();

        public ContainableItem GetItem(int index) => productList.GetItem(index) as ContainableItem;

        public ContainableItem GetByPosition(Position position) 
        {
            for (int i = 0; i < productList.Count(); i++)
                if (productList.GetItem(i).Equals(position))
                    return productList.GetItem(i) as ContainableItem;
            return null;
        }
    }
}
