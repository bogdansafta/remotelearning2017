﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine
{
    class CreditCard : Payment
    {
        public double Value { get; set; }
    }
}
