﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine
{
    class Coin : Payment
    {
        public double Value { get; set; }
    }
}
