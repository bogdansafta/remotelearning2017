﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine
{
    class Banknote : Payment
    {
        public double Value { get; set; }
    }
}
